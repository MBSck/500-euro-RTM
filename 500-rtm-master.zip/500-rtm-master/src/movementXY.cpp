#include "movementXY.h"
#include "stdio.h"

scanGrid::scanGrid(uint16_t widthX, uint16_t widthY)
: maxX(widthX -1), maxY(widthY -1),currentX(0), currentY(0),currentDirection(0)
{}


scanGrid::scanGrid(uint16_t maxX, uint16_t maxY, uint16_t startX, uint16_t startY)
: maxX(maxX), maxY(maxY),currentX(startX), currentY(startY), currentDirection(0)
{}

bool scanGrid::moveOn(){
    switch(currentDirection){
        case false: 
            if(currentX<maxX){
                currentX++; //rightwise
            }else{
                if(currentY != maxY){
                    currentY++; //next row
                    currentDirection = true; //direction change
                }else{
                    return true; //all points scanned
                }
            }
            return false; 
            break;
        case true: 
            if(currentX>0){
                currentX--; //leftwise
            }else{
                if(currentY != maxY){   
                    currentY++; //next row
                    currentDirection = false; //direction change
                }else{
                    return true; //all points scanned
                }
            }
            return false;
            break;
        default:
            printf("error move \n");
            return false;
            
    }
}

uint16_t scanGrid::getCurrentX(){
    return currentX;
}

uint16_t scanGrid::getCurrentY(){
    return currentY;
}

void scanGrid::setMaxX(uint16_t maxX){
    this->maxX = maxX;
}

void scanGrid::setMaxY(uint16_t maxY){
    this->maxY = maxY;
}

void scanGrid::setStartX(uint16_t startX){
    this->currentX = startX;
}

void scanGrid::setStartY(uint16_t startY){
    this->currentY = startY;
}

void scanGrid::setDirection(bool direction){
    this->currentDirection = direction;
}

uint16_t scanGrid::getMaxX(){
    return this->maxX;
}

uint16_t scanGrid::getMaxY(){
    return this->maxY;
}

bool scanGrid::getCurrentDirection(){
    return this->currentDirection;
}