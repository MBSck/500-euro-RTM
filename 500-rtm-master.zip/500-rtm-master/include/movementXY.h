#ifndef MOVEMENTXY
#define MOVEMENTXY

#include "stdint.h"

class scanGrid{
    uint16_t maxX; 
    uint16_t maxY;
    uint16_t currentX; 
    uint16_t currentY;
    bool currentDirection;


public:
    scanGrid(uint16_t maxX, uint16_t maxY);
    scanGrid(uint16_t maxX, uint16_t maxY, uint16_t startX, uint16_t startY);
    bool moveOn();

    void setMaxX(uint16_t);
    void setMaxY(uint16_t);
    void setStartX(uint16_t);
    void setStartY(uint16_t);
    void setDirection(bool);

    uint16_t getCurrentX();
    uint16_t getCurrentY();
    uint16_t getMaxX();
    uint16_t getMaxY();
    bool getCurrentDirection();
};

#endif